import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class SearchBig {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileInputStream inputStream = null;
		Scanner sc = null;
		String path=args[0];
		String searchString = args[1];
		long lineNo = 0;
		try {
			
			//reading files name in given folder
			File folder = new java.io.File(path);
			File[] flist =  folder.listFiles();
			
			//Iterating files list for searching
			 for (int i = 0; i < flist.length; i++) {
			      if (flist[i].isFile()) {
			    	 lineNo =0;
			        System.out.println("Searching File: " + flist[i].getName());
			        
			         inputStream = new FileInputStream(path + "/" + flist[i].getName());
					    sc = new Scanner(inputStream, "UTF-8");
					    while (sc.hasNextLine()) {
					    	lineNo++;
					        String line = sc.nextLine();
					        if (line.indexOf(searchString) != -1)
					        {
					        System.out.println("  Line no.:" + lineNo + " : " + line);
					         //System.out.println(line);
					        }
					   }
					  //   note that Scanner suppresses exceptions
					    if (sc.ioException() != null) {
					        throw sc.ioException();
					    }
			        
			        
			      } else if (flist[i].isDirectory()) {
			        System.out.println("Directory " + flist[i].getName());
			      }
			    }
	



				 
				 
		   // inputStream = new FileInputStream(path);
		  //  sc = new Scanner(inputStream, "UTF-8");
		  //  while (sc.hasNextLine()) {
		  //      String line = sc.nextLine();
		        // System.out.println(line);
		 //   }
		    // note that Scanner suppresses exceptions
		 //   if (sc.ioException() != null) {
		 //       throw sc.ioException();
		  //  }
		} finally {
		    if (inputStream != null) {
		        inputStream.close();
		    }
		    if (sc != null) {
		        sc.close();
		    }
		}
	}

}
